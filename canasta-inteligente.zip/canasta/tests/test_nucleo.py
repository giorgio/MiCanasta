"""Pruebas sin gastar cuota: simulan el cliente de Gemini. Ejecutar: python tests/test_nucleo.py"""
import sys; import os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import nucleo as n

class Resp:
    def __init__(s, obj): s.parsed = obj; s.text = None
class Err(Exception):
    def __init__(s, code): s.code = code
class FakeModels:
    def __init__(s, seq): s.seq = list(seq); s.calls = []
    def generate_content(s, model, contents, config):
        s.calls.append(model); x = s.seq.pop(0)
        if isinstance(x, Exception): raise x
        return Resp(x)
class Fake:
    def __init__(s, seq): s.models = FakeModels(seq)

def item(p, c, pr, t="Tía"):
    return n.ItemCompra(producto=p, categoria="Despensa", cantidad=c, unidad="kg", tienda=t, precio_unitario_usd=pr, motivo="barato")
def plan(items):
    return n.PlanCompras(resumen="ok", items=items, menu_semana_ejemplo=[], consejos=["a"])

# validaciones
assert not n.validar_plan(0, 2, ["Tía"]).ok
assert not n.validar_plan(9000, 2, ["Tía"]).ok
assert not n.validar_plan(100, 2, []).ok
v = n.validar_plan(40, 4, ["Tía"]); assert v.ok and v.avisos
assert not n.validar_recetas("  ").ok
assert n.validar_recetas("arroz").avisos

# plan dentro de presupuesto
c = Fake([plan([item("Arroz", 10, 1.0), item("Huevo", 2, 4.5, "Mercado municipal")])])
r = n.generar_plan(c, 100, 2, 3, "", ["Tía", "Mercado municipal"], "", "", "")
assert r["total"] == 19 and r["dentro_presupuesto"] and not r["corregido"]

# se pasa -> corrige
c = Fake([plan([item("Arroz", 100, 2.0)]), plan([item("Arroz", 30, 2.0)])])
r = n.generar_plan(c, 80, 2, 3, "", ["Tía"], "", "", "")
assert r["corregido"] and r["total"] == 60 and r["dentro_presupuesto"]

# item inválido y tienda no elegida
c = Fake([plan([item("X", 0, 1), item("Pan", 1, 1, "Supermaxi")])])
r = n.generar_plan(c, 50, 1, 3, "", ["Tía"], "", "", "")
assert len(r["plan"].items) == 1 and len(r["avisos"]) == 2

# 429 en principal -> respaldo
c = Fake([Err(429), plan([item("Arroz", 5, 1)])])
r = n.generar_plan(c, 50, 1, 3, "", ["Tía"], "", "", "")
assert r["modelo"] == n.MODELO_RESPALDO

# cuota agotada en ambos
c = Fake([Err(429), Err(429)])
try: n.generar_plan(c, 50, 1, 3, "", ["Tía"], "", "", ""); raise SystemExit("debió fallar")
except n.ErrorIA as e: assert "límite" in str(e)

# clave inválida
c = Fake([Err(403)])
try: n.generar_plan(c, 50, 1, 3, "", ["Tía"], "", "", ""); raise SystemExit("debió fallar")
except n.ErrorIA as e: assert "clave" in str(e)

# recetas
rr = n.RespuestaRecetas(recetas=[], aviso="No son alimentos")
out, _ = n.generar_recetas(Fake([rr]), "piedra, clavo", 2, "")
assert out.aviso

print("TODAS LAS PRUEBAS OK")
